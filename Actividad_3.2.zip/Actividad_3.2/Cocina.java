
/**
 * Write a description of class Cocina here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Cocina
{
    // instance variables - replace the example below with your own
    public Estufa estufa;
    public Refri refri;
    public Repisa repisa[];
    public int reps;

    /**
     * Constructor for objects of class Cocina
     */
    public Cocina()
    {
        // initialise instance variables
        repisa = new Repisa[5];
        reps=0;
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public void set_estufa(Estufa e){
        this.estufa=e;
    }
    public void set_refri(Refri r){
        this.refri=r;
    }
    public void set_repisa(Repisa rs){
        repisa[reps]=rs;
        reps++;
    }
}
