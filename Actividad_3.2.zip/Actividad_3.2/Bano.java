
/**
 * Write a description of class Bano here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bano
{
    // instance variables - replace the example below with your own
    public Wc wc;

    /**
     * Constructor for objects of class Bano
     */
    public Bano()
    {
        // initialise instance variables
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    
}
