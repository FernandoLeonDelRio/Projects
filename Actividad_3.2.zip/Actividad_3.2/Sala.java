
/**
 * Write a description of class Sala here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Sala
{
    // instance variables - replace the example below with your own
    public Sillon sillon;
    public Tv tv;
    public Tapete tapete;

    /**
     * Constructor for objects of class Sala
     */
    public Sala()
    {
        // initialise instance variables
        
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public void set_sillon(Sillon sil){
        this.sillon=sil; 
    }
    public void set_tv(Tv t){
        this.tv=t; 
    }
    public void set_tapete(Tapete tap){
        this.tapete=tap; 
    }
}
