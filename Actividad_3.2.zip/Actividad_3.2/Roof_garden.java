
/**
 * Write a description of class Roof_garden here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Roof_garden
{
    // instance variables - replace the example below with your own
    public Asador asador;
    /**
     * Constructor for objects of class Roof_garden
     */
    public Roof_garden()
    {
        // initialise instance variables
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public void set_asador(Asador as){
        this.asador=as;
    }
}
