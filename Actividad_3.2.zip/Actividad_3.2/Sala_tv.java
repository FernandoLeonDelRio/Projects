
/**
 * Write a description of class Sala_tv here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Sala_tv
{
    // instance variables - replace the example below with your own
    public Home_theatre ht;

    /**
     * Constructor for objects of class Sala_tv
     */
    public Sala_tv()
    {
        // initialise instance variables
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public void set_homthea(Home_theatre h){
        this.ht=h; 
    }
}
