
/**
 * Write a description of class Garage here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Garage
{
    // instance variables - replace the example below with your own
    public Coche coche[];
    public int nco;
    public Moto moto[];
    public int nmo;
    /**
     * Constructor for objects of class Garage
     */
    public Garage()
    {
        // initialise instance variables
        coche = new Coche[2];
        nco=0;
        moto = new Moto[2];
        nmo=0;
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public void set_coche(Coche cs){
        coche[nco]=cs;
        nco++;
    }
    public void set_moto(Moto ms){
        moto[nmo]=ms;
        nmo++;
    }
}
