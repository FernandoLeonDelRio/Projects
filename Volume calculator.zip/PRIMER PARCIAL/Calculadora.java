
/**
 * Write a description of class Calculadora here.
 * 
 * @author Carlos Pardo Castro, Fernando Leon Del Rio
 * @version 04/09/2024
 */
import java.util.Scanner;
public class Calculadora
{
    // instance variables - replace the example below with your own
    public static int opc;
    public static Cilindro cilindro;
    public static Cubo cubo;
    public static Piramide piramide;
    public static Esfera esfera;

    public Calculadora()
    {
        // initialise instance variables
        
    }

    public static void main(){
        Scanner lect = new Scanner(System.in);
        do{
            System.out.println("Seleccione que figura calcular");
            System.out.println("1) CILINDRO");
            System.out.println("2) CUBO");
            System.out.println("3) PIRAMIDE");
            System.out.println("4) ESFERA");
            System.out.println("0) SALIR");
            opc = lect.nextInt();
            switch(opc){
                case 1:
                    cilindro = new Cilindro();
                    cilindro.volumen_cilindro();
                    break;
                case 2:
                    cubo = new Cubo();
                    cubo.volumen_cubo();
                    break;
                case 3:
                    piramide = new Piramide();
                    piramide.volumen_piramide();
                    break;
                case 4:
                    esfera = new Esfera();
                    esfera.volumen_esfera();
                    break;
                case 0:
                    System.out.println("Saliendo...");
                    break;
                default:
                    System.out.println("Opcion invalida");
                    break;
            }
        
        }while(opc!=0);
    }
}
