


public class Cubo extends Figura
{
    public double res;

    /**
     * Constructor for objects of class Cubo
     */
    public Cubo()
    {
        // initialise instance variables
        
    }
    
    public void volumen_cubo(){
        
        System.out.println("Ingresa el area:");
        set_area();
        res = a*a*a;
        System.out.println("El resultado es: "+res);
        
    }


}
