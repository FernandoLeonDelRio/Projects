
/**
 * Write a description of class Piramide here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Piramide extends Figura
{
    public double res;
    
    public Piramide()
    {
        // initialise instance variables
        
    }
    
    public void volumen_piramide(){
        
        System.out.println("Ingresa la altura:");
        set_altura();
        System.out.println("Ingresa la area:");
        set_area();
        
        res = (a*a)*h/3.0;
        System.out.println("El resultado es: "+res);
        
    }

    
}
