
/**
 * Write a description of class Esfera here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Esfera extends Figura
{
    public double res;
    public Esfera()
    {
        // initialise instance variables
        
    }
    public void volumen_esfera(){
        
        System.out.println("Ingresa el radio:");
        set_radio();
        set_pi();
        res = 4.0/3.0*pi*r*r*r;
        System.out.println("El resultado es: "+res);
        
    }

    
}
