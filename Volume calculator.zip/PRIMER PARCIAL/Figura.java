import java.util.Scanner;
public class Figura
{
    // instance variables - replace the example below with your own
    public double a;
    public double h;
    public double r;
    public double pi;

    public Figura()
    {
        pi = 3.1416;
    }
    
    public void set_area(){
        Scanner lect = new Scanner(System.in);
        a = lect.nextDouble();
       
    }
    
    public void set_altura(){
        Scanner lect = new Scanner(System.in);
        h = lect.nextDouble();
        
    }
    
    public void set_radio(){
        Scanner lect = new Scanner(System.in);
        r = lect.nextDouble();
    }
    
    public void set_pi(){
        this.pi=3.1416;
    }
    


    
}
