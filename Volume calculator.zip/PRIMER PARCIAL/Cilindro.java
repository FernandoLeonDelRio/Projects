
/**
 * Write a description of class Cilindro here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import java.util.Scanner;
public class Cilindro extends Figura
{
    
    public double res;
    
    public Cilindro()
    {
        
        
    }
    
    public void volumen_cilindro(){
        
        
        System.out.println("Ingresa el radio:");
        set_radio();
        System.out.println("Ingresa la altura:");
        set_altura();
        set_pi();
        res = pi*r*r*h;
        System.out.println("El resultado es: "+res);
        
    }
    
    

    
}
