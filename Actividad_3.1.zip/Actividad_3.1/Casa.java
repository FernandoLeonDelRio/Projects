
/**
 * Write a description of class Casa here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Casa
{
    // instance variables - replace the example below with your own
    public int n_cuartos;
    public Bano bano[];
    public int nb;
    public Recamara recamara[];
    public int recs;
    public Cocina cocina;
    public Comedor comedor[];
    public int comes;
    public Sala sala[];
    public int ns;
    public Sala_tv salatv;
    public Roof_garden rg;

    /**
     * Constructor for objects of class Casa
     */
    public Casa()
    {
        // initialise instance variables
        bano = new Bano[2];
        nb=0;
        recamara= new Recamara[4];
        recs=0;
        comedor = new Comedor[2];
        comes=0;
        sala = new Sala[2];
        ns=0;
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public void set_cocina(Cocina c){
        this.cocina=c;   
    }
    public void set_salatv(Sala_tv st){
        this.salatv=st;
    }
    public void set_sala(Sala s){
        sala[ns]=s;
        ns++;
    }
    public void set_recamara(Recamara re){ 
        recamara[recs]=re;
        recs++;
    }
    public void set_comedor(Comedor co){
        comedor[comes]=co;
        comes++;
    }
    public void set_roofgarden(Roof_garden rf){
        this.rg=rf; 
    }
    public void set_bano(Bano b){
        bano[nb]=b;
        nb++;
    }
}
