
/**
 * Write a description of class Comedor here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Comedor
{
    // instance variables - replace the example below with your own
    public Mesa mesa;
    public Silla silla[];
    public int sils;
    /**
     * Constructor for objects of class Comedor
     */
    public Comedor()
    {
        // initialise instance variables
        silla = new Silla[4];
        sils=0;
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public void set_mesa(Mesa m){
        this.mesa=m; 
    }
    public void set_silla(Silla si){
        silla[sils]=si;
        sils++; 
    }
}
