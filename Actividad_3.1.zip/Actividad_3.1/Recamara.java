
/**
 * Write a description of class Recamara here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Recamara
{
    // instance variables - replace the example below with your own
    public Cama cama[];
    public int camas;

    /**
     * Constructor for objects of class Recamara
     */
    public Recamara()
    {
        // initialise instance variables
        cama= new Cama[2];
        camas=0;
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public void set_cama(Cama ca){
        cama[camas]=ca;
        camas++; 
    }
}
