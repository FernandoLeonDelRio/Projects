
/**
 * Write a description of class Main here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import java.util.Scanner;
public class Main
{
    // instance variables - replace the example below with your own
    public static Alumno alumno;
    public static Libreria lib;
    

    /**
     * Constructor for objects of class Main
     */
    public Main()
    {
        // initialise instance variables
        
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public static void Main()
    {
        // put your code here
        alumno=new Alumno();
        Scanner lect=new Scanner(System.in);
        System.out.println("Proporcione el nombre del alumno");
        alumno.nombre=lect.nextLine();
        lib=new Libreria();
        lib.add_libro();
        lib.vender(alumno);
    }
}
