
/**
 * Write a description of class Libro here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Libro
{
    // instance variables - replace the example below with your own
    public String autor;
    public String titulo;
    public String editorial;
    public double precio;

    /**
     * Constructor for objects of class Libro
     */
    public Libro()
    {
        
    }
    
    public Libro (String a, String t, String e, double p){
        autor=a;
        titulo=t;
        editorial = t;
        precio = p;
    }
    public void set_precio(double p){
        this.precio=p;
    }
}
