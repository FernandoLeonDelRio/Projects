import java.util.Scanner;
public class Libreria
{
    // instance variables - replace the example below with your own
    public Libro libros[];
    public int nli;
    public Persona empleado;
    public Alumno clientes[];
    public int ncl;
    public String nom_lib;

    public Libreria(){
        libros = new Libro[100];
        nli = 0;
        clientes = new Alumno[10];
        ncl = 0;
        nom_lib="Libreria UPAEP";
    }
    public void set_empleado(String n, int e, String g){
        this.empleado = new Persona();
        empleado.set_nombre(n);
        empleado.set_edad(e);
        empleado.set_genero(g);
    }
    public void add_libro(){
        Scanner lect = new Scanner(System.in);
        System.out.println("Cuantos desea agregar?");
        int c = lect.nextInt();
        lect.nextLine();
        for(int i=0;i<c;i++){
            System.out.println("Proporcione el autor");
            String a= lect.nextLine();
            System.out.println("Proporcione el titulo");
            String t= lect.nextLine();
            System.out.println("Proporcione la editorial");
            String e= lect.nextLine();
            System.out.println("Proporcione el precio");
            double p= lect.nextDouble();
            lect.nextLine();
            libros[nli] = new Libro (a,t,e,p);
            nli++;
        }
    }
    public int buscar_libro(String t){
        for(int i=0;i<nli;i++){
            if(libros[i].titulo.compareTo(t)==0){
                return(i);
            }
        }
        return(-1);
    }
    public void vender(Alumno c){
        System.out.println("Ingrese el titulo del libro que desea vender: ");
        Scanner lect = new Scanner(System.in);
        String t=lect.nextLine();
        int l;
        if((l=buscar_libro(t))!=-1){
            if(c.saldo>=libros[l].precio){
                c.set_saldo(c.saldo-libros[l].precio);
                c.cheques[c.nc]= new Cheque (nom_lib,"06/09/2024", libros[l].precio,"Santander", c.nombre);
                c.cheques[c.nc].imprimeCheque();
                c.nc++;
                c.facturas[c.nf]= new Factura (c.nombre,libros[l].titulo,libros[l].precio,"Jose Lopez");
                c.facturas[c.nf].imprimeFactura();
                c.nf++;
                System.out.println("El libro "+t+" fue vendido");
                libros[l].titulo="No disponible";
            }
        }else{
            System.out.println("El libro no se encuentra disponible");
        }
    }
    
}
