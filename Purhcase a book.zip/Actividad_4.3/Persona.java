
/**
 * Write a description of class Persona here.
 * 
 * @author Fernando Leon Del Rio
 * @version 02/09/2024
 */
public class Persona
{
    // instance variables - replace the example below with your own
    public String nombre;
    public int edad;
    public String genero;
    
    public Persona()
    {
        // initialise instance variables
    }
    
    public void set_nombre(String n){
        this.nombre=n;
    }
    public void set_edad(int e){
        this.edad=e;
    }
    public void set_genero(String g){
        this.genero=g;
    }
}
