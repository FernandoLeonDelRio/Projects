
public class Alumno extends Persona
{
    public int matricula;
    public String carrera;
    public double saldo;
    public Libro libros[];
    public int nl;
    public Cheque cheques[];
    public int nc;
    public Factura facturas[];
    public int nf;
    public Alumno()
    {
        libros = new Libro[10];
        nl=0;
        cheques = new Cheque[10];
        nc=0;
        facturas = new Factura[10];
        nf=0;
        saldo = 20000;
    }
    public void set_saldo(double s){
        this.saldo=s;
    }
    public void set_carrera(String c){
        this.carrera=c;
    }
    public void set_matricula(int m){
        this.matricula=m;
    }
}
