/**
 * Write a description of class Cheque here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Cheque
{
    // instance variables - replace the example below with your own
    public String nombre_d;
    public String fecha;
    public double cantidad;
    public String banco;
    public String propietario;

    /**
     * Constructor for objects of class Cheque
     */
    public Cheque()
    {
        // initialise instance variables
        
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public Cheque (String nd,String f, double c, String b, String p){
        this.nombre_d=nd;
        this.fecha=f;
        this.cantidad=c;
        this.banco=b;
        this.propietario=p;
    }
    public void imprimeCheque(){
        System.out.println("-----------------------------------------------");
        System.out.println("Nombre de destinatario: "+nombre_d);
        System.out.println("Fecha: "+fecha);
        System.out.println("Cantidad: "+cantidad);
        System.out.println("Banco: "+banco);
        System.out.println("Nombre del propietario: "+propietario);
        System.out.println("-----------------------------------------------");
    }
}
