public class Factura 
{
    // instance variables - replace the example below with your own
    //Nombre alumno, titulo, precio, nombre del empleado, libreria,
    public String nombre;
    public String titulo;
    public double precio;
    public String empleado;
    public String nomlib="Libreria UPAEP";
    
    public Factura()
    {
        // initialise instance variables
        
    }
    public Factura(String n,String t,double p,String e){
        this.nombre=n;
        this.titulo=t;
        this.precio=p;
        this.empleado=e;
    }
    public void imprimeFactura(){
        System.out.println("-----------------------------------------------");
        System.out.println("Nombre de destinatario: "+nombre);
        System.out.println("Titulo: "+titulo);
        System.out.println("Precio: "+precio);
        System.out.println("Empleado: "+empleado);
        System.out.println("Nombre de la libreria: "+nomlib);
        System.out.println("-----------------------------------------------");
    }
}
