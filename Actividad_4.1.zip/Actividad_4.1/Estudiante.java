
/**
 * Write a description of class Estudiante here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Estudiante extends Persona
{
    // instance variables - replace the example below with your own
    public int matricula;
    public String institucion;
    public double promedio;

    /**
     * Constructor for objects of class Estudiante
     */
    public Estudiante()
    {
        // initialise instance variables
        
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public void set_matricula(int m){
        this.matricula=m;
    }
    public void set_institución(String i){
        this.institucion=i;
    }
    public void set_promedio(double p){
        this.promedio=p;
    }
    public double get_promedio(){
        return(promedio);
    }
}
