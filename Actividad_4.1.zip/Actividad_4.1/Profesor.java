
/**
 * Write a description of class Profesor here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Profesor extends Persona
{
    // instance variables - replace the example below with your own
    public String materias[];
    public int nm;
    public String cedulas[]; 
    public int nc;
    public String contrato;//hora clase, nomina, solidario

    /**
     * Constructor for objects of class Profesor
     */
    public Profesor()
    {
        // initialise instance variables
        materias = new String[10];
        nm=0;
        cedulas = new String[5];
        nc=0;
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public void set_materias(String m){
        materias[nm]=m;
        nm++;
    }
    public void set_cedulas(String c){
        materias[nc]=c;
        nc++;
    }
    public void get_materias(){
        System.out.println("Materias impartidas:");
        for(int i=0;i<nm;i++){
            System.out.println(materias[i]);
        }
    }
    public void set_contrato(String c){
        this.contrato=c;
    }
}
