
/**
 * Write a description of class Estudiante_TI here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Estudiante_TI extends Estudiante
{
    // instance variables - replace the example below with your own
    public String carrera;
    public int id;
    public int semestre;
    public Computadora compu;
    public Profesor tutor;

    /**
     * Constructor for objects of class Estudiante_TI
     */
    public Estudiante_TI()
    {
        // initialise instance variables
        
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public void set_compu(Computadora c){
        this.compu=c;
    }
    public void set_id(int i){
        this.id=i;
    }
    public void set_tutor(Profesor p){
        this.tutor=p;
    }
}
