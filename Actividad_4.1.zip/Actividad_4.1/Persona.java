
/**
 * Write a description of class Persona here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Persona
{
    // instance variables - replace the example below with your own
    public int edad;
    public String genero;
    public String nombre;
    public String grado;

    /**
     * Constructor for objects of class Persona
     */
    public Persona()
    {
        // initialise instance variables
        
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public void set_edad(int e){
        this.edad=e;
    }
    public void set_grado(String g){
        this.grado=g;
    }
    public void set_genero(String ge){
        this.genero=ge;
    }
    public void set_nombre(String n){
        this.nombre=n;
    }
    public String get_nombre(){
        return(nombre);
    }
    public int get_edad(){
        return(edad);
    }
}
