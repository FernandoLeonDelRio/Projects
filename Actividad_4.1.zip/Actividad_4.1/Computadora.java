
/**
 * Write a description of class Computadora here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Computadora
{
    // instance variables - replace the example below with your own
    public String marca;
    public String procesador;
    public int memoria;
    public String sistema;

    /**
     * Constructor for objects of class Computadora
     */
    public Computadora()
    {
        // initialise instance variables
        
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public int sampleMethod()
    {
        // put your code here
        return 0;
    }
}
