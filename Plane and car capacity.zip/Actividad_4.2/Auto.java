
/**
 * Write a description of class Auto here.
 * 
 * @author Fernando León
 * @version 30/08/2024
 */
import java.util.Scanner;
public class Auto
{
    public Compu compu;
    public boolean encendido;
    public int capacidad;
    public boolean ventana;
    /**
     * Constructor for objects of class Auto
     */
    public Auto()
    {
        capacidad=5;
        encendido=false;
        ventana=false;
        compu=new Compu();
    }
    public void set_compu(Compu c){
        this.compu=c;
    }
    public void avanzar(){
        if(encendido==true){
            compu.set_tarea("Avanzar");
            
        }else{
            System.out.println("El carro esta apagado");
        }
    }
    public void encender(){
        encendido=true;
        compu.encender();
    }
    public void apagar(){
        encendido=false;
        compu.apagar();
    }
    public void subir(){
        if(encendido==true){
            if(capacidad>0){
                capacidad--;
                System.out.println("Capacidad = "+capacidad);
            }else{
                System.out.println("El carro esta lleno");
            }
        }else{
            System.out.println("El carro esta apagado");
        }
    }
    public void ventanas(){
        if(encendido==true){
            Scanner lect=new Scanner(System.in);
            System.out.println("Quiere cerrar o abrir las ventanas (1 abrir, 0 cerrar): ");
            int p=lect.nextInt();
            if(p==0){
                ventana=false;
            }else{
                ventana=true;
            }
            if(ventana==true){
                System.out.println("Ventana abierta");
            }else{
                System.out.println("Ventana cerrada");
            }
        }else{
            System.out.println("El carro esta apagado");
        }
    }
    public void viaje(){
        encender();
        Scanner lect=new Scanner(System.in);
        System.out.println("Cantidad de pasajeros");
        int p=lect.nextInt();
        if(p<=5 && p>0){
            compu.set_tarea("Subir");
            for(int i=0;i<p;i++){
                subir();
            }
            compu.set_tarea("Arrancar");
            ventanas();
            avanzar();
            compu.set_tarea("Frenar");
            compu.set_tarea("Parar");
            compu.set_tarea("Bajar pasajeros");
            capacidad=5;
            compu.set_tarea("Apagar");
            apagar();
        }else{
            System.out.println("Error, sobrepasa la capacidad del avion");
        }
    }
}   
