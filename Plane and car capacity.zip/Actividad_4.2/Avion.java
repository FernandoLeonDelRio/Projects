
/**
 * Write a description of class Avion here.
 * 
 * @author Fernando Leon Del Rio
 * @version 28/08/2024
 */
import java.util.Scanner;
public class Avion
{
    // instance variables - replace the example below with your own
    public Compu compu;
    public boolean encendido;
    public String modelo;
    public int capacidad;

    public Avion()
    {
        // initialise instance variables
        capacidad=50;
        encendido = false;
        compu = new Compu();
        
    }
    public void set_compu(Compu c){
        this.compu=c;
    }
    public void volar(){
        if(encendido==true){
            compu.set_tarea("Volar");
            
        }else{
            System.out.println("El avion esta apagado");
        }
    }
    public void encender(){
        encendido=true;
        compu.encender();
    }
    public void apagar(){
        encendido=false;
        compu.apagar();
    }
    public void abordar(){
        if(encendido==true){
            if(capacidad>0){
                capacidad--;
                System.out.println("Capacidad = "+capacidad);
            }else{
                System.out.println("El avion esta lleno");
            }
        }else{
            System.out.println("El avion esta apagado");
        }
    }
    public void viaje(){
        encender();
        Scanner lect=new Scanner(System.in);
        System.out.println("Cantidad de pasajeros");
        int p=lect.nextInt();
        if(p<=50 && p>0){
            compu.set_tarea("Abordar");
            for(int i=0;i<p;i++){
                abordar();
            }
            compu.set_tarea("Despegar");
            volar();
            compu.set_tarea("Descender");
            compu.set_tarea("Aterrizar");
            compu.set_tarea("Bajar pasajeros");
            capacidad=50;
            compu.set_tarea("Apagar");
            apagar();
        }else{
            System.out.println("Error, sobrepasa la capacidad del avion");
        }
    }
}
