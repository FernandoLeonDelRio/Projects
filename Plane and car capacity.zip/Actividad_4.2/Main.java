
/**
 * Write a description of class Main here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Main
{
    // instance variables - replace the example below with your own
    public static Avion avion;
    public static Auto auto;
    
    public Main()
    {
        // initialise instance variables
        
    }

    public static void main(String arg[]){
        System.out.println("Avion");
        avion = new Avion();
        avion.viaje();
        System.out.println("Auto");
        auto = new Auto();
        auto.viaje();
    }
}
