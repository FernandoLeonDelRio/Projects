
/**
 * Write a description of class Compu here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Compu
{
    // instance variables - replace the example below with your own
    public int ram;
    public String procesador;
    public int discoduro;
    public String tareas[];
    public int nt;
    public boolean encendido;

    /**
     * Constructor for objects of class Compu
     */
    public Compu()
    {
        // initialise instance variables
        nt=0;
        tareas = new String[25];
        encendido=false;
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public void set_ram(int r){
        this.ram=r;
    }
    public void set_tarea(String t){
        tareas[nt]=t;
        System.out.println(tareas[nt]);
        nt++;
    }
    public void set_procesador(String p){
        this.procesador=p;
    }
    public void set_dd(int d){
        this.discoduro=d;
    }
    public void encender(){
        encendido=true;
        nt=0;
    }
    public void apagar(){
        encendido=false;
        nt=0;
    }
}
